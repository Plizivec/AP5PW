﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Application.Abstraction;
using Project.Application.ViewModels;
using Project.Domain.Entities;
using Project.Infrastructure.Database;

namespace Project.Application.Implementation
{
    public class HomeService : IHomeService
    {


        public void ReloadCategoriesAndRecipes()
        {
            var databaseInit = new DatabaseInit(); // Instantiate DatabaseInit
            var updatedCategories = databaseInit.GetCategories();
            var updatedRecipes = databaseInit.GetRecipes();

            // Update the Categories and Recipes in your ViewModel
            var viewModel = GetHomeIndexViewModel();
            viewModel.Categories = updatedCategories;
            viewModel.Recipes = updatedRecipes;
        }

        public RecipeViewModel GetHomeIndexViewModel()
        {
            RecipeViewModel viewModel = new RecipeViewModel();
            viewModel.Categories = DatabaseFake.Categories;

            viewModel.Recipes = DatabaseFake.Recipes;
            return viewModel;
        }
    }
}
