﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Domain.Entities
{
    public class Recipe : Entity<int>
    {
        public string Name { get; set; }
        public string Instructions { get; set; }
        public int TimeForRecipe { get; set; }
        public string Difficulty { get; set; }
        public decimal Price { get; set; }
        public string Ingredients { get; set; }
        //public ICollection<Ingredience> Ingredience { get; set; }
        public string StravPref { get; set; }
        public double Rating { get; set; }
        public int[] Categories { get; set; }
        public List<Category> CategoriesList { get; set; }
        public int[] SelectedCategoryIds { get; set; }
        public string ImageSrc { get; set; }
    }
}
