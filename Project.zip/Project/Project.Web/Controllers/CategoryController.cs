﻿using Microsoft.AspNetCore.Mvc;
using Project.Application.Abstraction;
using Project.Web.Models;
using System.Collections.Generic;
using Project.Domain.Entities;

namespace Project.Web.Controllers
{
    public class CategoryController : Controller
    {
        private readonly IHomeService _homeService;
        private readonly IRecipeAdminService _recipeAdminService;

        public CategoryController(IHomeService homeService, IRecipeAdminService recipeAdminService)
        {
            _homeService = homeService;
            _recipeAdminService = recipeAdminService;
        }

        public IActionResult Category(int [] categoryId)
        {
            List<Recipe> recipes = GetRecipesByCategories(categoryId);
            return View(recipes);
        }
        private List<Recipe> GetRecipesByCategories(int[] categoryIds)
        {
            // Use your HomeService to get all recipes
            IList<Recipe> allRecipes = _homeService.GetHomeIndexViewModel().Recipes;

            // Filter recipes by categories
            List<Recipe> recipesInCategories = new List<Recipe>();

            foreach (var recipe in allRecipes)
            {
                // Check if the recipe has at least one category that matches the selected category IDs
                if (recipe.Categories.Any(id => categoryIds.Contains(id)))
                {
                    recipesInCategories.Add(recipe);
                }
            }

            return recipesInCategories;
        }

        public IActionResult AllRecipes()
        {
            IList<Recipe> recipes = _recipeAdminService.Select();
            return View("Category", recipes);
        }
    }
}