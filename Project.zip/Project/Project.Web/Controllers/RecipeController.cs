﻿using Microsoft.AspNetCore.Mvc;
using Project.Application.Abstraction;
using Project.Web.Models;
using System.Collections.Generic;
using Project.Domain.Entities;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Project.Web.Controllers
{
    public class RecipeController : Controller
    {
        private readonly IRecipeAdminService _recipeAdminService;
        private readonly IHomeService _homeService;

        public RecipeController(IRecipeAdminService recipeAdminService, IHomeService homeService)
        {
            _recipeAdminService = recipeAdminService;
            _homeService = homeService;
        }

        public IActionResult Index()
        {
            IList<Recipe> recipes = _recipeAdminService.Select();
            return View("RecipeAdmin", recipes);
        }


        [HttpGet]
        public IActionResult Create()
        {
            var categories = _homeService.GetHomeIndexViewModel().Categories;
            ViewBag.CategoryList = new MultiSelectList(categories, "Id", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(Recipe recipe, int[] selectedCategoryIds)
        {
            int recipeId = _recipeAdminService.Create(recipe);

            if (selectedCategoryIds != null)
            {
                _recipeAdminService.AssociateRecipeWithCategories(recipeId, selectedCategoryIds);
            }

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int Id)
        {
            bool deleted = _recipeAdminService.Delete(Id);

            if (deleted)
            {
                return RedirectToAction(nameof(RecipeController.Index));
            }
            else
            {
                return NotFound();
            }
        }

        public IActionResult Recipe(int recipeId)
        {
            Recipe recipe = GetRecipeById(recipeId);
            if (recipe == null)
            {
                return NotFound();
            }

            // Retrieve the selected categories for this recipe
            IList<Category> selectedCategories = GetSelectedCategories(recipeId);

            ViewData["SelectedCategories"] = selectedCategories;

            return View(recipe);
        }

        private IList<Category> GetSelectedCategories(int recipeId)
        {
            Recipe recipe = GetRecipeById(recipeId);

            if (recipe != null)
            {
                // Get all categories from the HomeService
                IList<Category> allCategories = _homeService.GetHomeIndexViewModel().Categories;

                // Filter the categories based on the recipe's category IDs
                IList<Category> selectedCategories = allCategories
                    .Where(category => recipe.Categories.Contains(category.Id))
                    .ToList();

                return selectedCategories;
            }

            return new List<Category>();
        }

        private Recipe GetRecipeById(int recipeId)
        {
            IList<Recipe> allRecipes = _recipeAdminService.Select();
            Recipe recipe = allRecipes.FirstOrDefault(r => r.Id == recipeId);
            return recipe;
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Recipe recipe = GetRecipeById(id);

            if (recipe == null)
            {
                return NotFound();
            }

            var categories = _homeService.GetHomeIndexViewModel().Categories;
            ViewBag.CategoryList = new MultiSelectList(categories, "Id", "Name", recipe.SelectedCategoryIds);
            return View("Edit", recipe);
        }

        [HttpPost]
        public IActionResult Edit(Recipe recipe, int[] selectedCategoryIds)
        {
            _recipeAdminService.Edit(recipe);

            if (selectedCategoryIds != null)
            {
                _recipeAdminService.AssociateRecipeWithCategories(recipe.Id, selectedCategoryIds);
            }

            return RedirectToAction("Index");
        }
    }
}